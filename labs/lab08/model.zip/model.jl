# # Лабораторная работа №8: Конкуренция двух фирм
#
# **Вариант 1**  
# Параметры:
# - $p_{cr}=15$, $N=17$, $q=1$
# - $\tau_1=11$, $\tau_2=14$, $\tilde p_1=8$, $\tilde p_2=6$
# - $M_1(0)=2.5$, $M_2(0)=1.5$ (млн. ед.)
#
# ## Инициализация проекта
using DrWatson, DifferentialEquations, Plots, DataFrames, JLD2

# Создаём каталоги для результатов и графиков
script_name = splitext(basename(@__FILE__))[1]
mkpath(plotsdir(script_name))
mkpath(datadir(script_name))

# ## Задание параметров
p_cr = 15.0
N = 17.0
q = 1.0
t1 = 11.0; t2 = 14.0
p1 = 8.0; p2 = 6.0
M0_1 = 2.5; M0_2 = 1.5
tspan = (0.0, 30.0)

# ## Расчёт коэффициентов
a1 = p_cr / (t1^2 * p1^2 * N * q)
a2 = p_cr / (t2^2 * p2^2 * N * q)
b  = p_cr / (t1^2 * p1^2 * t2^2 * p2^2 * N * q)
c1 = (p_cr - p1) / (t1 * p1)
c2 = (p_cr - p2) / (t2 * p2)

# ## Случай 1: чисто рыночная конкуренция
# Уравнения:
# $$
# \frac{dM_1}{d\theta}=M_1-\frac{b}{c_1}M_1M_2-\frac{a_1}{c_1}M_1^2,\quad
# \frac{dM_2}{d\theta}=\frac{c_2}{c_1}M_2-\frac{b}{c_1}M_1M_2-\frac{a_2}{c_1}M_2^2
# $$
function case1!(du, u, p, θ)
    M1, M2 = u
    a1, a2, b, c1, c2 = p
    du[1] = M1 - (b/c1)*M1*M2 - (a1/c1)*M1^2
    du[2] = (c2/c1)*M2 - (b/c1)*M1*M2 - (a2/c1)*M2^2
end

prob1 = ODEProblem(case1!, [M0_1, M0_2], tspan, (a1, a2, b, c1, c2))
sol1 = solve(prob1, Tsit5(), saveat=0.1)

# Визуализация
plot(sol1, idxs=[1,2], label=["M₁" "M₂"],
     xlabel="θ (безразмерное время)", ylabel="Оборотные средства M (млн.)",
     title="Случай 1: чисто рыночная конкуренция", lw=2)
savefig(plotsdir(script_name, "case1_plot.png"))

# ## Случай 2: добавлен социально-психологический фактор
# В первом уравнении коэффициент перекрёстного влияния увеличен на 0.001:
# $\frac{dM_1}{d\theta}=M_1-\left(\frac{b}{c_1}+0.001\right)M_1M_2-\frac{a_1}{c_1}M_1^2$
function case2!(du, u, p, θ)
    M1, M2 = u
    a1, a2, b, c1, c2 = p
    du[1] = M1 - (b/c1 + 0.001)*M1*M2 - (a1/c1)*M1^2
    du[2] = (c2/c1)*M2 - (b/c1)*M1*M2 - (a2/c1)*M2^2
end

prob2 = ODEProblem(case2!, [M0_1, M0_2], tspan, (a1, a2, b, c1, c2))
sol2 = solve(prob2, Tsit5(), saveat=0.1)

plot(sol2, idxs=[1,2], label=["M₁" "M₂"],
     xlabel="θ", ylabel="M (млн.)",
     title="Случай 2: с учётом общественного предпочтения", lw=2)
savefig(plotsdir(script_name, "case2_plot.png"))

# ## Анализ стационарных состояний (случай 1)
# Из системы $dM_1/d\theta=0$, $dM_2/d\theta=0$ получаем ненулевое решение:
# $$
# \begin{cases}
# a_1 M_1 + b M_2 = c_1,\\
# b M_1 + a_2 M_2 = c_2.
# \end{cases}
# $$
det = a1*a2 - b^2
M1_star = (c1*a2 - b*c2) / det
M2_star = (a1*c2 - b*c1) / det
println("Стационарные значения (ненулевые):")
println("M₁* = $M1_star")
println("M₂* = $M2_star")

# Сохраняем все результаты
@save datadir(script_name, "results.jld2") sol1 sol2 M1_star M2_star

println("Работа завершена. Графики сохранены в $(plotsdir(script_name))")
